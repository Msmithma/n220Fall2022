//Using HTML5 & JS (not p5)


//Write an application that has a div with the number 100 in it
//when each the div is clicked
//Show that number minus 5 in that div
//For instance: After 3 clicks the div should display 85


//use arithmetic operators
//if/else bool
//use onclick and display function 

let myName = true;
let otherName = false ;

if (myName){
console.log('100'); 
}
if(otherName){
    console.log( otherName <100); 
}
//displau after 3 clicks 
//object.onclick 
else {
    console.log('85')
  }

