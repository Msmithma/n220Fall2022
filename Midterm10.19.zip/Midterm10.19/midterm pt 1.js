//HTML5 &  JS (not P5)

//Create an application with an element on the screen (such as a div), with the word "There" in it.

//Each time the element is clicked, display a different word, going from "There" to "you" and ending with "are".

//(The whole application can be tested with two clicks to see each word.)

//define variables with "let" 
let there = true; 
let you = false;
let are = false; 
        
//use if/ else statements to indicate what happens if the words "there", "you", and "are" are used. 
//screen element 
<script> 
        
        if (there) { 
document.getElementById("There").onclick = there() {if(there)};
            

             if (you) {
document.getElementById("you").onclick = you() {if(you)};
            }

        { else { 
document.getElementById("are").onclick = are() {else(are)};
            }
Object.onclick = function() {myScript}; 

</script>
